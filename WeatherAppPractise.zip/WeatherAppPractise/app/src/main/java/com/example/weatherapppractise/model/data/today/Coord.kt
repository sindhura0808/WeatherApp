package com.example.weatherapppractise.model.data.today

data class Coord(
    val lat: Double,
    val lon: Double
)