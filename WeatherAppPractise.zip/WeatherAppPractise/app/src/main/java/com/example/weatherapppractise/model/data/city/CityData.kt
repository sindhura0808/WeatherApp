package com.example.weatherapppractise.model.data.city

class CityData : ArrayList<CityDataItem>()