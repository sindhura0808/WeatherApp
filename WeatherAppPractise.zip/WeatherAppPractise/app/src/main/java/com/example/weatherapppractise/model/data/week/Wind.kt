package com.example.weatherapppractise.model.data.week

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)