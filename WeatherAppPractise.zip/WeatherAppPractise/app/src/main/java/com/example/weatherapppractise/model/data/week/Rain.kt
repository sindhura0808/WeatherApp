package com.example.weatherapppractise.model.data.week

data class Rain(
    val `3h`: Double
)