package com.example.weatherapppractise.model.data.week

import android.icu.util.Calendar

data class Week(
    val city: City,
    val cnt: Int,
    val cod: String,
    val list: List<WeekOfData>,
    val message: Int
)