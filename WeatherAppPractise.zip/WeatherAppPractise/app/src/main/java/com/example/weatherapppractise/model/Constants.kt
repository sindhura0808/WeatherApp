package com.example.weatherapppractise.model

object Constants {
    //https://api.openweathermap.org/data/2.5/weather?q=Dallas&appid=03ee1d15536e4356623335b084d05029
    const val BASE_URL = "https://api.openweathermap.org"
    const val API_KEY = "a090314144b2e9aa128cda27f59c272c"
}