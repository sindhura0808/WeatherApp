package com.example.weatherapppractise.model.data.week

data class Sys(
    val pod: String
)