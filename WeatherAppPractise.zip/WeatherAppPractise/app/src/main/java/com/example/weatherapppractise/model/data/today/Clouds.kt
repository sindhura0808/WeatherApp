package com.example.weatherapppractise.model.data.today

data class Clouds(
    val all: Int
)